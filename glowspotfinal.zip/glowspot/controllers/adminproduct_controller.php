
<?php

require('../classes/adminproduct_class.php');



function viewAllPalmersController(){
    
    $admin_actions = new Product();
    return $admin_actions->viewAllPalmers();
}

function viewAllTeaController(){
    
    $admin_actions = new Product();
    return $admin_actions->viewAllTea();
}

function viewAllCetaphilController(){
    
    $admin_actions = new Product();
    return $admin_actions->viewAllCetaphil();
}

function viewAllCeraveController(){
    
    $admin_actions = new Product();
    return $admin_actions->viewAllCerave();
}

function viewAllMglController(){
    
    $admin_actions = new Product();
    return $admin_actions->viewAllMgl();
}

function checkProductController($product_name){
    
    $admin_actions = new Product();
    return $admin_actions->checkProduct($product_name);
}

function addProductController($brand,$product_title,$price,$desc, $img,$keywords){
    
    $admin_actions = new Product();
    return $admin_actions->addProduct($brand,$product_title,$price,$desc, $img,$keywords);
}

function editProductController($brand,$product_title,$price,$desc, $img,$keywords,$pid){
    
    $admin_actions = new Product();
    return $admin_actions->editProduct($brand,$product_title,$price,$desc, $img,$keywords,$pid);
}


function searchDbController($phrase){
    $product_actions = new product ();
    return $product_actions->searchDb($phrase);
}

function deleteOneProductController($id){
    
    $admin_actions = new Product();
    return $admin_actions->deleteOneProduct($id);
}

function productCountController(){
    
    $admin_actions = new Product();
    return $admin_actions->productCount();
}




?>