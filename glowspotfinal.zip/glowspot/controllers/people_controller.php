<?php

require('../classes/people_class.php');


function admin_login_controller ($email){
    
    $admin_actions = new People();

    return $admin_actions->admin_login ($email);
}

function customerCheckcontroller ($email){
    
    $admin_actions = new People();

    return $admin_actions->customer_check ($email);
}

function searchDbController($phrase){
    $people_actions = new People ();
    return $people_actions->searchDb($phrase);
}


function viewAllCustomersController(){
    
    $admin_actions = new People();

    return $admin_actions->viewAllCustomers();
}

function viewAllAdminsController(){
    
    $admin_actions = new People();

    return $admin_actions->viewAllAdmins();
}

function addCustomerController ($name,$email,$pswd,$country,$city,$contact,$role){
    
    $admin_actions = new People();

    return $admin_actions->addCustomer($name,$email,$pswd,$country,$city,$contact,$role);
}

function deleteOneCustomerController($customer_id){
    
    $admin_actions = new People();

    return $admin_actions->deleteOneCustomer($customer_id);
}

function customerCountController(){
    
    $admin_actions = new People();

    return $admin_actions->customerCount();
}



function editCustomerContoller($name,$email,$pass_hash,$country,$city,$contact,$id){
    
    $admin_actions = new People();

    return $admin_actions->editCustomer($name,$email,$pass_hash,$country,$city,$contact,$id);
}







?>