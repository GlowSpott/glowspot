<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link rel="stylesheet" href="../css/all_product_style.css">

    
</head>
<body>
    

<form method='post' action='product_search_results.php'>

<div>
    <label>Search Products</label>
    <input type='text' name = 'search_phrase' placeholder = 'search here ...'>

    <br>
    <input type='submit' name='search' value='Submit'>
</div>

</form>



<?php
				if(isset($_POST['search'])){
					$phrase = $_POST['search_phrase'];


                require ('../controllers/product_controller.php');

                $results = searchDbController($phrase);

                foreach( $results as $row ) {
			?>

<div class="card">
       <a href="single_product.php?id=<?php echo $row['product_id'] ?>"><img src="../images/product/<?php echo $row["product_image"]; ?>" style="width:100%"> </a> 

        <h1><?php echo $row["product_title"] ?></h1>
        <p class="price"><?php echo $row["product_price"]; ?></p>
        <a href="../actions/add_to_cart.php?id=<?php echo $row["product_id"]; ?>" name="addToCart" class="cart-btn">Add to cart</a>
        <a  href="single_product.php?id=<?php echo $row['product_id'] ?>" >View Product </a>
</div>

<?php

        }
                }

?>

</body>
</html>