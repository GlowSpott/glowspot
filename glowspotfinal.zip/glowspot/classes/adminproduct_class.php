
<?php
// palmers,tee tree, cetaphil, cerave,mgl naturals

require('../settings/db_class.php');

class Product extends Connection{

    function viewAllPalmers(){
        $query = "select * from products where product_brand = 'palmers' order by product_id;";
        return $this->fetch($query);
    }

    function viewAllTea(){
        $query = "select * from products where product_brand = 'Tea Tree' order by product_id;";
        return $this->fetch($query);
    }

    function viewAllCetaphil(){
        $query = "select * from products where product_brand = 'cetaphil' order by product_id ;";
        return $this->fetch($query);
    }

    function viewAllCerave(){
        $query = "select * from products where product_brand = 'cerave'  order by product_id;";
        return $this->fetch($query);
    }

    function viewAllMgl(){
        $query = "select * from products where product_brand = 'mgl' order by product_id;";
        return $this->fetch($query);
    }

    function checkProduct($product_name) {
        $query = "select * from products where product_name = '$product_name';";
        return $this->fetch($query);
    }

    function  addProduct($brand,$product_title,$price,$desc, $img,$keywords) {
        $query = "insert into products(product_name,product_price,product_image,product_keywords,product_brand,product_desc) values('$product_title','$price','$img','$keywords','$brand','$desc');";
        return $this->query($query);
    }

    function  deleteOneProduct($product_id) {
        $query = "delete from products where product_id = '$product_id';";
        return $this->query($query);
    }

    function productCount(){
        $query = "SELECT COUNT(product_id) from products;";
        return $this->query($query);
    }

    function editProduct($brand,$product_title,$price,$desc, $img,$keywords,$pid){
        // update record for specified customer
        return $this->query("UPDATE `products` SET `product_name` ='$product_title' ,`product_brand` = '$brand', `product_price` = 'price' ,`product_desc` = '$desc',`product_image` ='$img',`product_keywords` = '$keywords' WHERE `product_id` =' $pid'; ");
    }

    function searchDb($phrase){
        $query = "SELECT * FROM `products` WHERE `product_name` LIKE '%$phrase%' ORDER BY `product_name`;";
        return $this->fetch($query);
    }


}

?>