<?php

// set up constants for database connection credentials
// database, user, password, server

// define('SERVER', 'localhost');
// define('USER', 'id17815449_localhost');
// define('DATABASE', 'id17815449_labs');
// define('PASSWORD', 'b!><U~cSQrRz00I^');



// XAMPP testing

define('SERVER', 'localhost');
define('USER', 'root');
define('DATABASE', 'glowspot');
define('PASSWORD', '');

?>