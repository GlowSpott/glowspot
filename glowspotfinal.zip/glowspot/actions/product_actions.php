<?php
require('../controllers/adminproduct_controller.php');




if(isset($_POST['addProduct'])){
    // retrieve form details
    $product_title = $_POST['product_title'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $desc = $_POST['desc'];
    $img = $_POST['img'];
    $keywords = $_POST['key'];
  
    
    addProductController($brand,$product_title,$price,$desc, $img,$keywords);
    header("location:../view/products_table.php");
                // $results = addProductController($brand,$product_title,$price,$desc, $image,$keywords);
                // if ($results = true) {
                //     header("location:../view/products_table.php"); 
                //     exit(); 
                //     } else {
                //     echo 'no';
                // }
  
              }  
           
    
 // eedit  btn process
if(isset($_POST["editprobtn"])){

    $product_title = $_POST['pname'];
    $pid = $_POST['pid'];
    $brand = $_POST['pbrand'];
    $price = $_POST['pprice'];
    $desc = $_POST['pdesc'];
    $img = $_POST['pimg'];
    $keywords = $_POST['pkey'];
 
    editProductController($brand,$product_title,$price,$desc, $img,$keywords,$pid);
    // header("location:../view/products_table.php"); 
     }
 
 
 if (isset($_POST["palmeditbtn"])) {
    $p_id = $_POST['palmedit'];
    header("location: pupdate.php?id=$p_id;"); 
  
 }
  
  
  

//delete button process for product cetaphil table
if(isset($_POST["cetadelbtn"])){

    $ceta_id = $_POST['cetadel'];
    deleteOneProductController($ceta_id);
    header("location:../view/products_table.php"); 
        exit(); 
     }

//delete button process for product cerave table
if(isset($_POST["ceradelbtn"])){

    $cera_id = $_POST['ceradel'];
    deleteOneProductController($cera_id);
    header("location:../view/products_table.php"); 
        exit(); 
     }

//delete button process for product tea trea table
if(isset($_POST["teadelbtn"])){

    $tea_id = $_POST['teadel'];
    deleteOneProductController($tea_id);
    header("location:../view/products_table.php"); 
        exit(); 
     }

     //delete button process for product mgl table
if(isset($_POST["mgldelbtn"])){

    $mgl_id = $_POST['mgldel'];
    deleteOneProductController($mgl_id);
    header("location:../view/products_table.php"); 
        exit(); 
     }


     //delete button process for product palmers table

     if(isset($_POST["palmdelbtn"])){

    $palm_id = $_POST['palmdel'];
    deleteOneProductController($palm_id);
    header("location:../view/products_table.php"); 
        exit(); 
        }


?>